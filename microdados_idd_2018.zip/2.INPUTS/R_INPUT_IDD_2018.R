##################################################################################
#  MEC/INEP/DAES (Diretoria de Avalia��o da Educa��o Superior)                   # 
#  Coordena��o Geral de Controle de Qualidade da Educa��o Superior               # 	
#--------------------------------------------------------------------------------#
#  Programa:                                                                     #
#  R_INPUT_IDD_2018.R (Pasta "INPUTS")                 	                       #
#--------------------------------------------------------------------------------#
#  Descri��o: 															                                     #
#  Programa para Leitura dos Microdados do IDD   2018                            #
#                                                                                #
#********************************************************************************#
#  Obs: Para executar este programa é necessário salvar o arquivo              #
# "microdados_idd_2018.txt" (Pasta "DADOS") no diret�rio "C:\" do computador. 	 #     
#                                                                                #  
#********************************************************************************#

microdados_idd <- read.table("C:/microdados_idd_2018.txt",header=T,sep=";")